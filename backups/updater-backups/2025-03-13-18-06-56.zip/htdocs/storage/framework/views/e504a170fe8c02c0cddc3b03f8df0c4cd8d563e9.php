<div class="container">
	<div class="footer fadein" style="margin:5% 0px 35px 0px;">
	<?php if(env('DISPLAY_FOOTER') === true): ?>
		<?php if(env('DISPLAY_FOOTER_HOME') === true): ?><a class="footer-hover spacing" href="<?php if(str_replace('"', "", EnvEditor::getKey('HOME_FOOTER_LINK')) === "" ): ?><?php echo e(url('')); ?><?php else: ?><?php echo e(str_replace('"', "", EnvEditor::getKey('HOME_FOOTER_LINK'))); ?><?php endif; ?>"><?php echo e(footer('Home')); ?></a><?php endif; ?>
		<?php if(env('DISPLAY_FOOTER_TERMS') === true): ?><a class="footer-hover spacing" href="<?php echo e(url('')); ?>/pages/<?php echo e(strtolower(footer('Terms'))); ?>"><?php echo e(footer('Terms')); ?></a><?php endif; ?>
		<?php if(env('DISPLAY_FOOTER_PRIVACY') === true): ?><a class="footer-hover spacing" href="<?php echo e(url('')); ?>/pages/<?php echo e(strtolower(footer('Privacy'))); ?>"><?php echo e(footer('Privacy')); ?></a><?php endif; ?>
		<?php if(env('DISPLAY_FOOTER_CONTACT') === true): ?><a class="footer-hover spacing" href="<?php echo e(url('')); ?>/pages/<?php echo e(strtolower(footer('Contact'))); ?>"><?php echo e(footer('Contact')); ?></a><?php endif; ?>
	<?php endif; ?>
	</div>

	<?php if(env('DISPLAY_CREDIT') === true): ?>
	
	<div class="credit-footer"><a style="text-decoration: none;" class="" href="https://linkstack.org" target="_blank" title="<?php echo e(__('messages.Learn more about LinkStack')); ?>">
		<div style="vertical-align: middle;display: inline-block;padding-bottom:50px;" class="credit-hover hvr-grow fadein">
			<img style="top:9px;" class="credit-icon image-footer1 generic" src="<?php echo e(asset('assets/linkstack/images/logo.svg')); ?>" alt="LinkStack">
			<a href="https://linkstack.org" target="_blank" title="<?php echo e(__('messages.Learn more')); ?>" class="credit-txt credit-txt-clr credit-text">Powered by LinkStack</a>
		</div>
	</a></div>
	<?php endif; ?>
	</div><?php /**PATH /htdocs/resources/views/layouts/footer.blade.php ENDPATH**/ ?>