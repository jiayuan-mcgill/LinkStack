<div class="modal" tabindex="-1" role="dialog" id="<?php echo e($getModalIdString()); ?>">


    <div class="modal-dialog modal-dialog-scrollable" role="document">

        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e($title); ?></h5>
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo e($slot); ?>


            </div>
            <div class="modal-footer">
             <?php echo e($buttons); ?>


                
            </div>
        </div>
    </div>
</div>
<?php /**PATH /htdocs/resources/views/components/modal.blade.php ENDPATH**/ ?>