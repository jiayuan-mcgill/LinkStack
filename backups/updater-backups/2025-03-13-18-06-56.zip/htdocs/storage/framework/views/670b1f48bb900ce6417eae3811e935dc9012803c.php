<?php
$pages = DB::table('pages')->get();
foreach($pages as $page)
{
	//Gets value from database
}
?>

<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->make('layouts.lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('logo', null, []); ?>  <?php $__env->endSlot(); ?>

        <!-- Session Status -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <!-- Validation Errors -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <div style="max-width:480px" class="container mt-5 w-100">
          <div class="card p-5">
              <a href="<?php echo e(url('')); ?>" class="d-flex align-items-center mb-3">
                <!--Logo start-->
                <div class="logo-main">
                    <?php if(file_exists(base_path("assets/linkstack/images/").findFile('avatar'))): ?>
                    <div class="logo-normal">
                      <img class="img logo" src="<?php echo e(asset('assets/linkstack/images/'.findFile('avatar'))); ?>" style="width:auto;height:30px;">
                  </div>
                  <div class="logo-mini">
                    <img class="img logo" src="<?php echo e(asset('assets/linkstack/images/'.findFile('avatar'))); ?>" style="width:auto;height:30px;">
                  </div>
                    <?php else: ?>
                    <div class="logo-normal">
                      <img class="img logo" type="image/svg+xml" src="<?php echo e(asset('assets/linkstack/images/logo.svg')); ?>" width="30px" height="30px">
                  </div>
                  <div class="logo-mini">
                    <img class="img logo" type="image/svg+xml" src="<?php echo e(asset('assets/linkstack/images/logo.svg')); ?>" width="30px" height="30px">
                  </div>
                    <?php endif; ?>
                    </div>
                    <!--logo End-->
                <h4 class="logo-title ms-3"><?php echo e(env('APP_NAME')); ?></h4>
              </a>
              <h2 class="mb-2 text-center"><?php echo e(__('messages.Sign In')); ?></h2>
              <p class="text-center"><?php echo e(__('messages.Login to stay connected')); ?>.</p>
              <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                  <div class="col-lg-12">
                    <div class="form-group">
                      <label for="email" class="form-label"><?php echo e(__('messages.Email')); ?></label>
                      <input type="email" class="form-control" id="email" name="email" aria-describedby="email" placeholder=" " :value="old('email')" required autofocus >
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class="form-group">
                      <label for="password" class="form-label"><?php echo e(__('messages.Password')); ?></label>
                      <input type="password" class="form-control" id="password" aria-describedby="password" placeholder=" " name="password" required autocomplete="current-password" />
                    </div>
                  </div>
                  <div class="col-lg-12 d-flex justify-content-between">
                    <div class="form-check mb-3">
                      <input type="checkbox" class="form-check-input" name="remember" id="remember_me">
                      <label class="form-check-label" for="remember_me"><?php echo e(__('messages.Remember Me')); ?></label>
                    </div>
                    <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('messages.Forgot Password?')); ?></a>
                  </div>
                </div>
                <div class="d-flex justify-content-center">
                  <button type="submit" class="btn btn-primary"><?php echo e(__('messages.Sign In')); ?></button>
                </div>
                <?php if(env('ENABLE_SOCIAL_LOGIN') == 'true'): ?>
                <p class="text-center my-3"><?php echo e(__('messages.or sign in with other accounts?')); ?></p>
                <div class="d-flex justify-content-center">
                  <ul class="list-group list-group-horizontal list-group-flush">
                    <?php if(!empty(env('FACEBOOK_CLIENT_ID'))): ?>
                    <li class="list-group-item border-0 pb-0">
                      <a href="<?php echo e(route('social.redirect','facebook')); ?>">
                        <i class="bi bi-facebook"></i>
                      </a>
                    </li>
                    <?php endif; ?>
                    <?php if(!empty(env('TWITTER_CLIENT_ID'))): ?>
                    <li class="list-group-item border-0 pb-0">
                      <a href="<?php echo e(route('social.redirect','twitter')); ?>">
                        <i class="bi bi-twitter"></i>
                      </a>
                    </li>
                    <?php endif; ?>
                    <?php if(!empty(env('GOOGLE_CLIENT_ID'))): ?>
                    <li class="list-group-item border-0 pb-0">
                      <a href="<?php echo e(route('social.redirect','google')); ?>">
                        <i class="bi bi-google"></i>
                      </a>
                    </li>
                    <?php endif; ?>
                    <?php if(!empty(env('GITHUB_CLIENT_ID'))): ?>
                    <li class="list-group-item border-0 pb-0">
                      <a href="<?php echo e(route('social.redirect','github')); ?>">
                        <i class="bi bi-github"></i>
                      </a>
                    </li>
                    <?php endif; ?>
                  </ul>
                </div>
                <?php else: ?>
                <br>
                <?php endif; ?>
                <?php if((env('ALLOW_REGISTRATION')) and !config('linkstack.single_user_mode')): ?>
                <p class="mt-3 text-center">
                  <?php echo e(__('messages.Don’t have an account?')); ?> <a href="<?php echo e(route('register')); ?>" class="text-underline"><?php echo e(__('messages.Click here to sign up')); ?>.</a>
                </p>
                <?php endif; ?>
              </form>
            </div>
          </div>          

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH /htdocs/resources/views/auth/login.blade.php ENDPATH**/ ?>