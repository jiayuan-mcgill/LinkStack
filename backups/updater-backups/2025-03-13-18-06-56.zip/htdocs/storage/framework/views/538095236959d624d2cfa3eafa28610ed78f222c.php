<?php use App\Models\UserData; ?>

<!DOCTYPE html>
<?php echo $__env->make('layouts.lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<head>
  <meta charset="utf-8">

  <?php $GLOBALS['themeName'] = config('advanced-config.home_theme'); ?>
  <?php
  // Theme Config
  function theme($key){
  $key = trim($key);
  $file = base_path('themes/' . $GLOBALS['themeName'] . '/config.php');
    if (file_exists($file)) {
      $config = include $file;
    if (isset($config[$key])) {
      return $config[$key];
  }}
  return null;}
  
  // Theme Custom Asset
  function themeAsset($path){
  $path = url('themes/' . $GLOBALS['themeName'] . '/extra/custom-assets/' . $path);
  return $path;}
  ?>

  <!-- Custom icons font-awesome -->
  <script><?php echo file_get_contents(base_path("assets/external-dependencies/fontawesome.js")); ?></script>
  <style><?php echo str_replace('../', 'studio/', file_get_contents(base_path("assets/external-dependencies/fontawesome.css"))); ?></style>

  <?php echo $__env->make('layouts.fonts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

  <?php if(theme('enable_custom_code') == "true" and theme('enable_custom_head') == "true" and env('ALLOW_CUSTOM_CODE_IN_THEMES') == 'true'): ?><?php echo $__env->make($GLOBALS['themeName'] . '.extra.custom-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>

  <?php if($GLOBALS['themeName'] != '' and $GLOBALS['themeName'] != 'default'): ?>
  <link rel="stylesheet" href="themes/<?php echo e($GLOBALS['themeName']); ?>/share.button.css">
  <?php if(theme('use_default_buttons') == "true"): ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/brands.css')); ?>">
  <?php else: ?>
  <link rel="stylesheet" href="themes/<?php echo e($GLOBALS['themeName']); ?>/brands.css">
  <?php endif; ?>
  <link rel="stylesheet" href="themes/<?php echo e($GLOBALS['themeName']); ?>/skeleton-auto.css">
<?php if(file_exists(base_path('themes/' . $GLOBALS['themeName'] . '/animations.css'))): ?>
  <link rel="stylesheet" href="<?php echo asset('themes/' . $GLOBALS['themeName'] . '/animations.css') ?>">
<?php else: ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/animations.css')); ?>">
<?php endif; ?>

<?php else: ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/share.button.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/animations.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/brands.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/skeleton-auto.css')); ?>">
<?php endif; ?>
<style>.container{word-break: break-word;}</style>

  <meta name="robots" content="noindex, follow">

<style>.container{word-break: break-word;}</style>
</head>
<body>

<?php if(theme('enable_custom_code') == "true" and theme('enable_custom_body') == "true" and env('ALLOW_CUSTOM_CODE_IN_THEMES') == 'true'): ?><?php echo $__env->make($GLOBALS['themeName'] . '.extra.custom-body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>

<?php if($GLOBALS['themeName'] != '' and $GLOBALS['themeName'] != 'default'): ?>
    <!-- Enables parallax background animations -->
    <div class="background-container">
    <section class="parallax-background">
      <div id="object1" class="object1"></div>
      <div id="object2" class="object2"></div>
      <div id="object3" class="object3"></div>
      <div id="object4" class="object4"></div>
      <div id="object5" class="object5"></div>
      <div id="object6" class="object6"></div>
      <div id="object7" class="object7"></div>
      <div id="object8" class="object8"></div>
      <div id="object9" class="object9"></div>
      <div id="object10" class="object10"></div>
      <div id="object11" class="object11"></div>
      <div id="object12" class="object12"></div>
    </section>
    </div>
    <!-- End of parallax background animations -->
<?php endif; ?>

  <div class="container">
    <div class="row">
      <div class="column" style="margin-top: 15%">

        <?php if(file_exists(base_path("assets/linkstack/images/").findFile('avatar'))): ?>
        <img alt="avatar" src="<?php echo e(asset('assets/linkstack/images/'.findFile('avatar'))); ?>" width="auto" height="128px">
        <?php else: ?>
        <div class="logo-container fadein">
          <img src="<?php echo e(asset('assets/linkstack/images/logo.svg')); ?>" alt="Logo" style="width:150px; height:150px;">
        </div>
        <?php endif; ?>

        <h1 class="fadein"><?php echo e(config('app.name')); ?></h1>


        <style>.description-parent * {margin-bottom: 1em;}.description-parent {padding-bottom: 30px;}</style>
        <center><div class="fadein description-parent"><p class="fadein"><?php echo e(__('messages.Example page')); ?></p></div></center>
        
        

        <!-- Buttons -->
        <?php function strp($urlStrp){return str_replace(array('http://', 'https://'), '', $urlStrp);} ?>
        <?php $initial=1; // <-- Effectively sets the initial loading time of the buttons. This value should be left at 1. ?>
        <?php if(config('advanced-config.use_custom_buttons') == 'true'): ?>
                <?php $array = config('advanced-config.buttons'); ?>
                <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php $linkName = str_replace('default ','',$button['button']) ?>
                 <?php if($button['button'] === "custom" and ($button['custom_css'] === "" or $button['custom_css'] === "NULL") or (theme('allow_custom_buttons') == "false" and $button['button'] === "custom")): ?>
                 <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-<?php echo e($button['button']); ?> button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e($button['link']); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><?php if($button['icon'] == 'llc'): ?><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('\/assets/linkstack/icons\/')); ?>llc.svg"><?php else: ?><i style="color: <?php echo e($button['icon']); ?>" class="icon hvr-icon fa <?php echo e($button['icon']); ?>"></i><?php endif; ?> <?php echo e($button['title']); ?></a></div>
                 <?php elseif($button['button'] === "custom" and $button['custom_css'] != ""): ?>
                 <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-hover icon-hover" style="<?php echo e($button['custom_css']); ?>" rel="noopener noreferrer nofollow" href="<?php echo e($button['link']); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><?php if($button['icon'] == 'llc'): ?><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('\/assets/linkstack/icons\/')); ?>llc.svg"><?php else: ?><i style="color: <?php echo e($button['icon']); ?>" class="icon hvr-icon fa <?php echo e($button['icon']); ?>"></i><?php endif; ?><?php echo e($button['title']); ?></a></div>
                 <?php elseif($button['button'] === "buy me a coffee"): ?>
                 <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-coffee button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e($button['link']); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><img alt="button-icon" class="icon hvr-icon" src="<?php if(theme('use_custom_icons') == "true"): ?><?php echo e(url('themes/' . $GLOBALS['themeName'] . '/extra/custom-icons')); ?>/coffee<?php echo e(theme('custom_icon_extension')); ?> <?php else: ?><?php echo e(asset('\/assets/linkstack/icons\/')); ?>coffee.svg <?php endif; ?>">Buy me a Coffee</a></div>
                 <?php elseif($button['button'] === "custom_website" and ($button['custom_css'] === "" or $button['custom_css'] === "NULL") or (theme('allow_custom_buttons') == "false" and $button['button'] === "custom_website")): ?>
                 <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-custom_website button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e($button['link']); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><img alt="button-icon" class="icon hvr-icon" src="<?php if(file_exists(base_path("assets/favicon/icons/").localIcon($button['id']))): ?><?php echo e(url('assets/favicon/icons/'.localIcon($button['id']))); ?><?php else: ?><?php echo e(getFavIcon($button['id'])); ?><?php endif; ?>"><?php echo e($button['title']); ?></a></div>
                 <?php elseif($button['button'] === "custom_website" and $button['custom_css'] != ""): ?>
                 <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-hover icon-hover" style="<?php echo e($button['custom_css']); ?>" rel="noopener noreferrer nofollow" href="<?php echo e($button['link']); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><img alt="button-icon" class="icon hvr-icon" src="<?php if(file_exists(base_path("assets/favicon/icons/").localIcon($button['id']))): ?><?php echo e(url('assets/favicon/icons/'.localIcon($button['id']))); ?><?php else: ?><?php echo e(getFavIcon($button['id'])); ?><?php endif; ?>"><?php echo e($button['title']); ?></a></div>
                 <?php elseif($button['button'] === "space"): ?>
                 <?php 
                  if (is_numeric($button['title']) and $button['title'] < 10)
                  echo str_repeat("<br>",$button['title']);
                  elseif (is_numeric($button['title']) and $button['title'] >= 10)
                  echo str_repeat("<br>",10);
                  else
                  echo "<br><br><br>"
                  ?>
                 <?php elseif($button['button'] === "heading"): ?>
                 <h2><?php echo e($button['title']); ?></h2>
                 <?php else: ?>
                 <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-<?php echo e($button['button']); ?> button button-hover icon-hover" <?php if($button['link'] != ''): ?> href="<?php echo e($button['link']); ?>" target="_blank"<?php endif; ?>><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('\/assets/linkstack/icons\/') . $linkName); ?>.svg"><?php echo e(ucfirst($linkName)); ?></a></div>
                 <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
                <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><div class="button button-github button button-hover icon-hover"><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('assets/linkstack/icons/github.svg')); ?>">Github</div></div>
                <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><div class="button button-twitter button button-hover icon-hover"><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('assets/linkstack/icons/twitter.svg')); ?>">Twitter</div></div>
                <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><div class="button button-instagram button button-hover icon-hover"><img alt="button-icon" class="icon hvr-icon" src="<?php echo e(asset('assets/linkstack/icons/instagram.svg')); ?>">Instagram</div></div>
        <?php endif; ?>
          
      </div>
    </div>
  </div>

  <?php if(theme('enable_custom_code') == "true" and theme('enable_custom_body_end') == "true" and env('ALLOW_CUSTOM_CODE_IN_THEMES') == 'true'): ?><?php echo $__env->make($GLOBALS['themeName'] . '.extra.custom-body-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>

</body>
</html><?php /**PATH /htdocs/resources/views/demo.blade.php ENDPATH**/ ?>