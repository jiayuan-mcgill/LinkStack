<?php use App\Models\Button; $button = Button::find($button_id); if(isset($button->name)){$buttonName = $button->name;}else{$buttonName = 0;} ?>

<select style="display:none" name="button" class="form-control"><option class="button button-default email" value="phone"><?php echo e(__('messages.Phone')); ?></option></select>

<label for='title' class='form-label'><?php echo e(__('messages.Custom Title')); ?></label>
<input type='text' name='title' value='<?php echo e($link_title); ?>' class='form-control' />
<span class='small text-muted'><?php echo e(__('messages.Leave blank for default title')); ?></span><br>

<label for='link' class='form-label'><?php echo e(__('messages.Telephone number')); ?></label>
<input type='tel' name='link' value='<?php echo e(str_replace("tel:", "", $link_url)); ?>' class='form-control' required />
<span class='small text-muted'><?php echo e(__('messages.Enter your telephone number')); ?></span>

<?php /**PATH /htdocs/resources/views/components/pageitems/telephone-form.blade.php ENDPATH**/ ?>