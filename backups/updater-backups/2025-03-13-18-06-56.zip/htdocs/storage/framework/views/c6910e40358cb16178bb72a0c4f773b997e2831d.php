

<?php $__env->startSection('content'); ?>

<div class="conatiner-fluid content-inner mt-n5 py-0">
  <div class="row">   
      
   <div class="col-lg-12">
      <div class="card   rounded">
          <div class="card-body">
             <div class="row">
                 <div class="col-sm-12">  

                  <?php if(session()->has('success')): ?>
                  <div class="alert alert-success">
                      <?php echo e(session()->get('success')); ?>

                  </div>
              <?php endif; ?>
              
              <?php if(session()->has('error')): ?>
                  <div class="alert alert-danger">
                      <?php echo e(session()->get('error')); ?>

                  </div>
              <?php endif; ?>
              
              <?php if($_SERVER['QUERY_STRING'] === ''): ?>
              <section class="text-gray-400">
                      <h3 class="mb-4 card-header"><i class="bi bi-person"><?php echo e(__('messages.Account Settings')); ?></i></h3>
              <div class="card-body p-0 p-md-3">
              
                      <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
              <?php if(env('REGISTER_AUTH') != 'verified' or auth()->user()->role == 'admin'): ?>
                      <form  action="<?php echo e(route('editProfile')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <div class="form-group col-lg-8">
                          <h4>Email</h4>
                          <input type="email" class="form-control" name="email" value="<?php echo e($profile->email); ?>" required>
                        </div>
                        <button type="Change " class="mt-3 ml-3 btn btn-primary"><?php echo e(__('messages.Change email')); ?></button>
                      </form>
              <?php endif; ?>
              
              <br><br><form  action="<?php echo e(route('editProfile')); ?>" method="post">
                <?php echo csrf_field(); ?>
                  <div class="form-group col-lg-8">
                    <h4><?php echo e(__('messages.Password')); ?></h4>
                    <input type="password" name="password" class="form-control" placeholder="At least 8 characters" required>
                  </div>
                  <button type="Change " class="mt-3 ml-3 btn btn-primary"><?php echo e(__('messages.Change password')); ?></button>
                </form>
              
                <?php echo csrf_field(); ?>
                  <br><br><div class="form-group col-lg-8">
                    <h4>Role</h4>
                    <input type="text" class="form-control" value="<?php echo e(strtoupper($profile->role)); ?>" readonly>
                  </div>
              
              <?php if(env('ALLOW_USER_EXPORT') != false): ?>
              <div class="mt-3"><br><br><br>
                <h4><?php echo e(__('messages.Export user data')); ?></h4>
                <p><?php echo e(__('messages.Export your user data')); ?></p>
                <div class="row">
                  <div class="col-lg-8">
                    <button class="btn btn-outline-secondary">
                      <a href="<?php echo e(route('exportAll')); ?>">
                        <i class="bi bi-layer-backward"></i> <?php echo e(__('messages.Export all data')); ?>

                      </a>
                    </button>
                    <button class="btn btn-outline-secondary">
                      <a href="<?php echo e(route('exportLinks')); ?>">
                        <i class="bi bi-layer-backward"></i> <?php echo e(__('messages.Export links only')); ?>

                      </a>
                    </button>
                  </div>
                </div>
              </div>
              <?php endif; ?>
              
              <?php if(env('ALLOW_USER_IMPORT') != false): ?>
              <form action="<?php echo e(route('importData')); ?>" enctype="multipart/form-data" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group col-lg-8"><br><br><br>
                  <h4><?php echo e(__('messages.Import user data')); ?></h4>
                    <label><?php echo e(__('messages.Import your user data from another instance')); ?></label>
                    <input type="file" accept="application/JSON" class="form-control" id="customFile" name="import">
                </div>
              
                <button type="submit" class="mt-3 ml-3 btn btn-primary" onclick="return confirm('<?php echo e(__('messages.import.user.alert')); ?>')"><?php echo e(__('messages.Import')); ?></button>
              </form>
              <?php endif; ?>
              
              <br>
              
                        <br><button class="btn btn-danger"><a
                            href="<?php echo e(url('/studio/profile/?delete')); ?>" style="color:#FFFFFF;"><i class="bi bi-exclamation-octagon-fill"></i>
                            <?php echo e(__('messages.Delete your account')); ?></a></button>
                        </div>
              </section>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              
              <?php if($_SERVER['QUERY_STRING'] === 'delete'): ?>
              <div class="d-flex justify-content-center align-items-center" style="height:100vh;">
                <div class="text-center">
                  <h2 class="text-decoration-underline"><?php echo e(__('messages.You are about to delete')); ?></h2>
                  <p><?php echo e(__('messages.You are about to delete This action cannot be undone')); ?></p>
                  <div>
                    <button class="redButton btn btn-danger" style="filter: grayscale(100%);" disabled onclick="window.location.href = '<?php echo e(url('/studio/delete-user/') . "/" . Auth::id()); ?>';"><i class="bi bi-exclamation-diamond-fill"></i></button>
                    <button type="submit" class="btn btn-primary"><a style="color:#fff;" href="<?php echo e(url('/studio/profile')); ?>"><?php echo e(__('messages.Cancel')); ?></a></button>
                  </div>
                </div>
              </div>
              
              <script>
              var seconds = 10;
              var interval = setInterval(function() {
                document.querySelector(".redButton").innerHTML = --seconds;
              
                if (seconds <= 0)
                  clearInterval(interval);
              }, 1000);
              
              setTimeout(function(){
                document.querySelector(".redButton").disabled = false;
                document.querySelector(".redButton").innerHTML = '<?php echo e(__('messages.Delete account')); ?>';
                document.querySelector(".redButton").style.filter = "none";
              }, 10000);
              </script>

              <?php endif; ?>

                 </div>
             </div>
          </div>
       </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /htdocs/resources/views//studio/profile.blade.php ENDPATH**/ ?>