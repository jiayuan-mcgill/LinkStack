<label for='title' class='form-label'><?php echo e(__('messages.Heading Text:')); ?></label>
<input type='text' name='title' value='<?php echo e($link_title); ?>' class='form-control' />


<?php /**PATH /htdocs/resources/views/components/pageitems/heading-form.blade.php ENDPATH**/ ?>