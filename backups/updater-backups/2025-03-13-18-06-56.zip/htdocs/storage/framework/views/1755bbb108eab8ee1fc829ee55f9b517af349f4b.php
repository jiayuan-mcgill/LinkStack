<?php
$analyticsHTML = config('advanced-config.analytics');
$analyticsHTML = preg_replace("~<!--(.*?)-->~s", "", $analyticsHTML);
$analyticsHTML = trim($analyticsHTML);
?>

<?php if(preg_replace( "/\r|\n/", "", $analyticsHTML ) != ''): ?>
<!-- Analytics -->

<?php echo $analyticsHTML; ?>


<!-- /Analytics -->
<?php endif; ?>
<?php /**PATH /htdocs/resources/views/layouts/analytics.blade.php ENDPATH**/ ?>