

<?php $__env->startSection('content'); ?>

<div class="conatiner-fluid content-inner mt-n5 py-0">
    <div class="row">   
        
     <div class="col-lg-12">
        <div class="card   rounded">
            <div class="card-body">
               <div class="row">
                   <div class="col-sm-12">  
  
                    <?php $__env->startPush('sidebar-stylesheets'); ?>
                    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
                    <?php $__env->stopPush(); ?>
                    
                    <section class='text-gray-400'>
                    
                        <h3 class="card-header"><i class="bi bi-journal-plus"> <?php if($LinkID !== 0): ?> <?php echo e(__('messages.Submit')); ?> <?php else: ?> <?php echo e(__('messages.Add')); ?> <?php endif; ?> <?php echo e(__('messages.Block')); ?></i></h3>
                    
                        <div class='card-body'>
                            <form action="<?php echo e(route('addLink')); ?>" method="post" id="my-form">
                                <?php echo method_field('POST'); ?>
                                <?php echo csrf_field(); ?>
                                <input type='hidden' name='linkid' value="<?php echo e($LinkID); ?>" />
                    
                                <div class="form-group col-lg-8 flex justify-around">
                                    
                                    <div class="btn-group shadow m-2">
                                        <button type="button" id='btnLinkType' class="btn btn-primary rounded-pill" title='<?php echo e(__('messages.Click to change link blocks')); ?>' data-toggle="modal" data-target="#SelectLinkType"><?php echo e(__('messages.Select Block')); ?>

                                            <span class="btn-inner">
                                                <i class="bi bi-window-plus"></i>
                                            </span>
                                        </button><?php echo e(infoIcon(__('messages.Click for a list of available link blocks'))); ?>

                                          
                    
                    
                                        
                                        
                                        <input type='hidden' name='linktype_id' value='<?php echo e($linkTypeID); ?>'>
                    
                                    </div>
                                </div>
                    
                                
                    
                    
                                <div id='link_params' class='col-lg-8'></div>
                    
                    
                                <div class="d-flex align-items-center pt-4">
                                    <a class="btn btn-danger me-3" href="<?php echo e(url('studio/links')); ?>"><?php echo e(__('messages.Cancel')); ?></a>
                                    <button type="submit" class="btn btn-primary me-3"><?php echo e(__('messages.Save')); ?></button>
                                    <button type="button" class="btn btn-soft-primary me-3" onclick="submitFormWithParam('add_more')"><?php echo e(__('messages.Save and Add More')); ?></button>
                                    <script>
                                        function submitFormWithParam(paramValue) {
                                            // get the form element
                                            var form = document.getElementById("my-form");
                                            
                                            // check if all required fields are filled out
                                            var requiredFields = form.querySelectorAll("[required]");
                                            for (var i = 0; i < requiredFields.length; i++) {
                                                if (!requiredFields[i].value) {
                                                    alert("Please fill out all required fields.");
                                                    return false;
                                                }
                                            }
                                            
                                            // create a hidden input field with the parameter value
                                            var paramField = document.createElement("input");
                                            paramField.setAttribute("type", "hidden");
                                            paramField.setAttribute("name", "param");
                                            paramField.setAttribute("value", paramValue);
                                            // append the hidden input field to the form
                                            form.appendChild(paramField);
                                            // submit the form
                                            form.submit();
                                        }
                                        </script>
                                </div>                                
                    
                            </form>
                        </div>
                    </section>
                    <br><br>
                    
                    
                    
                    
                    <!-- Modal -->
                    <style>.modal-title{color:#000!important;}</style>
                    <?php if (isset($component)) { $__componentOriginal2bcebcb49cbd37095816ed3d3b22a3f8992f805c = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['title' => ''.e(__('messages.Select Block')).'','id' => 'SelectLinkType'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    
                        <div class="d-flex flex-row  flex-wrap p-3">
                    
                            <?php
                              $custom_order = [1, 2, 8, 6, 7, 3, 4, 5,];
                               $sorted = $LinkTypes->sortBy(function ($item) use ($custom_order) {
                                    return array_search($item['id'], $custom_order);
                             });
                            ?>
                    
                            <?php $__currentLoopData = $sorted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                            $title = __('messages.block.title.'.$lt['typename']); 
                            $description = __('messages.block.description.'.$lt['typename']); 
                            ?>
                            <a href="#" data-dismiss="modal" data-typeid="<?php echo e($lt['id']); ?>" data-typename="<?php echo e($title); ?>" class="hvr-grow m-2 w-100 d-block doSelectLinkType">
                                <div class="rounded mb-3 shadow-lg">
                                    <div class="row g-0">
                                        <div class="col-auto bg-light d-flex align-items-center justify-content-center p-3">
                                            <i class="<?php echo e($lt['icon']); ?> text-primary h1 mb-0"></i>
                                        </div>
                                        <div class="col">
                                            <div class="card-body">
                                                <h5 class="card-title text-dark mb-0"><?php echo e($title); ?></h5>
                                                <p class="card-text text-muted"><?php echo e($description); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>      
                            </a>                     
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                        </div>
                    
                         <?php $__env->slot('buttons', null, []); ?> 
                            <button type="button" class="btn btn-gray" data-dismiss="modal"><?php echo e(__('messages.Close')); ?></button>
                         <?php $__env->endSlot(); ?>
                    
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2bcebcb49cbd37095816ed3d3b22a3f8992f805c)): ?>
<?php $component = $__componentOriginal2bcebcb49cbd37095816ed3d3b22a3f8992f805c; ?>
<?php unset($__componentOriginal2bcebcb49cbd37095816ed3d3b22a3f8992f805c); ?>
<?php endif; ?>
  
                   </div>
               </div>
            </div>
         </div>
        </div>
        
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush("sidebar-scripts"); ?>
<script>
$(function() {
    LoadLinkTypeParams($("input[name='linktype_id']").val() , $("input[name=linkid]").val());

    $('.doSelectLinkType').on('click', function() {
        $("input[name='linktype_id']").val($(this).data('typeid'));
        $("#btnLinkType").html($(this).data('typename'));

        LoadLinkTypeParams($(this).data('typeid'), $("input[name=linkid]").val());

        $('#SelectLinkType').modal('hide');
    });


    function LoadLinkTypeParams($TypeId, $LinkId) {
        var baseURL = <?php echo "\"" . url('') . "\""; ?>;
        $("#link_params").html('<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>').load(baseURL + `/studio/linkparamform_part/${$TypeId}/${$LinkId}`);

    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /htdocs/resources/views/studio/edit-link.blade.php ENDPATH**/ ?>