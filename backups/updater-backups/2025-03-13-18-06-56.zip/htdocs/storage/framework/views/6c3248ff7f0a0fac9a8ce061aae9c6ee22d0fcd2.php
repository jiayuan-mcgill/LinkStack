<?php use App\Models\UserData; ?>

<!DOCTYPE html>
<?php echo $__env->make('layouts.lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<head>
  <meta charset="utf-8">


<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($link->name === "mastodon"): ?>
    <link href="<?php echo e($link->link); ?>" rel="me">
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
<?php
// Theme Config
if (!function_exists('theme')) {
  function theme($key){
$key = trim($key);
$file = base_path('themes/' . $GLOBALS['themeName'] . '/config.php');
  if (file_exists($file)) {
    $config = include $file;
  if (isset($config[$key])) {
    return $config[$key];
}}
return null;}
}

// Theme Custom Asset
if (!function_exists('themeAsset')) {
function themeAsset($path){
$path = url('themes/' . $GLOBALS['themeName'] . '/extra/custom-assets/' . $path);
return $path;}
}
?>

<?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $GLOBALS['themeName'] = $info->theme; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(theme('enable_custom_code') == "true" and theme('enable_custom_head') == "true" and env('ALLOW_CUSTOM_CODE_IN_THEMES') == 'true'): ?><?php echo $__env->make($GLOBALS['themeName'] . '.extra.custom-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>

<?php echo $__env->make('layouts.analytics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php if(config('advanced-config.linkstack_title') != '' and env('HOME_URL') === ''): ?>
  <title><?php echo e($userinfo->name); ?> <?php echo e(config('advanced-config.linkstack_title')); ?></title>
  <?php elseif(env('CUSTOM_META_TAGS') == 'true' and config('advanced-config.title') != ''): ?>
  <title><?php echo e(config('advanced-config.title')); ?></title>
  <?php elseif(env('HOME_URL') != ''): ?>
  <title><?php echo e($userinfo->name); ?></title>
  <?php else: ?>
  <title><?php echo e($userinfo->name); ?> 🔗 <?php echo e(config('app.name')); ?> </title>
  <?php endif; ?>

<?php if(env('CUSTOM_META_TAGS') == 'true'): ?>
  <?php echo $__env->make('layouts.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php else: ?>
  <meta name="description" content="<?php echo e($userinfo->littlelink_description); ?>">
  <meta name="author" content="<?php echo e($userinfo->name); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<?php endif; ?>

<?php if(theme('allow_custom_background') != "false"): ?>
<?php
$customBackgroundFile = findBackground($userinfo->id);
$customBackgroundPath = base_path('assets/img/background-img/'.$customBackgroundFile);
$customBackgroundURL = url('assets/img/background-img/'.$customBackgroundFile);
$customBackgroundExists = file_exists($customBackgroundPath);
if($customBackgroundExists == true){
  $customBackgroundBrightness = analyzeImageBrightness($customBackgroundFile);
    } else {
 $customBackgroundBrightness = false;}
?>

<?php if($customBackgroundExists == true): ?>
<style>
  body {
    background-image: url('<?php echo e($customBackgroundURL); ?>') !important;
    background-size: cover !important;
    background-attachment: fixed !important;
    background-repeat: no-repeat !important;
    background-position: center !important;
  }
</style>
<?php endif; ?>
<?php endif; ?>
  
<!--#### BEGIN Meta Tags social media preview images  ####-->
  <!-- This shows a preview for title, description and avatar image of users profiles if shared on social media sites -->

    <!-- Facebook Meta Tags -->
    <meta property="og:url" content="<?php echo e(url('')); ?>/<?php echo e("@" . $littlelink_name); ?>">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo e($userinfo->name); ?>">
    <meta property="og:description" content="<?php echo e(strip_tags($userinfo->littlelink_description)); ?>">
    <?php if(file_exists(base_path(findAvatar($userinfo->id)))): ?>
    <meta property="og:image" content="<?php echo e(url(findAvatar($userinfo->id))); ?>">
    <?php elseif(file_exists(base_path("assets/linkstack/images/").findFile('avatar'))): ?>
    <meta property="og:image" content="<?php echo e(url("assets/linkstack/images/")."/".findFile('avatar')); ?>">
    <?php else: ?>
    <meta property="og:image" content="<?php echo e(asset('assets/linkstack/images/logo.svg')); ?>">
    <?php endif; ?>
    
    <!-- Twitter Meta Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta property="twitter:domain" content="<?php echo e(url('')); ?>/<?php echo e("@" . $littlelink_name); ?>">
    <meta property="twitter:url" content="<?php echo e(url('')); ?>/<?php echo e("@" . $littlelink_name); ?>">
    <meta name="twitter:title" content="<?php echo e($userinfo->littlelink_name); ?>">
    <meta name="twitter:description" content="<?php echo e(strip_tags($userinfo->littlelink_description)); ?>">
    <?php if(file_exists(base_path(findAvatar($userinfo->id)))): ?>
    <meta name="twitter:image" content="<?php echo e(url(findAvatar($userinfo->id))); ?>">
    <?php elseif(file_exists(base_path("assets/linkstack/images/").findFile('avatar'))): ?>
    <meta name="twitter:image" content="<?php echo e(url("assets/linkstack/images/")."/".findFile('avatar')); ?>">
    <?php else: ?>
    <meta name="twitter:image" content="<?php echo e(asset('assets/linkstack/images/logo.svg')); ?>">
    <?php endif; ?>

<!--#### END Meta Tags social media preview images  ####-->

  <!-- Custom icons font-awesome -->
  
  <style><?php echo str_replace('../', 'studio/', file_get_contents(base_path("assets/external-dependencies/fontawesome.css"))); ?></style>

  <?php echo $__env->make('layouts.fonts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
  <style><?php echo file_get_contents(base_path("assets/linkstack/css/normalize.css")); ?></style>
  <style><?php echo file_get_contents(base_path("assets/linkstack/css/animate.css")); ?></style>
  <?php if(file_exists(base_path("assets/linkstack/images/").findFile('favicon'))): ?>
  <link rel="icon" type="image/png" href="<?php echo e(asset('assets/linkstack/images/'.findFile('favicon'))); ?>">
  <?php else: ?>
  <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('assets/linkstack/images/logo.svg')); ?>">
  <?php endif; ?>

<?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($info->theme != '' and $info->theme != 'default'): ?>

  <!-- LinkStack Theme: "<?php echo e($info->theme); ?>" -->

  <!-- Theme details: -->
  <meta name="designer" href="<?php echo e(url('') . "/theme/@" . $littlelink_name); ?>" content="<?php echo e(url('') . "/theme/@" . $littlelink_name); ?>">

  <link rel="stylesheet" href="themes/<?php echo e($info->theme); ?>/share.button.css">
  <?php if(theme('use_default_buttons') == "true"): ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/brands.css')); ?>">
  <?php else: ?>
  <link rel="stylesheet" href="themes/<?php echo e($info->theme); ?>/brands.css">
  <?php endif; ?>
  <link rel="stylesheet" href="themes/<?php echo e($info->theme); ?>/skeleton-auto.css">
<?php if(file_exists(base_path('themes/' . $info->theme . '/animations.css'))): ?>
  <link rel="stylesheet" href="<?php echo asset('themes/' . $info->theme . '/animations.css') ?>">
<?php else: ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/animations.css')); ?>">
<?php endif; ?>

<?php else: ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/share.button.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/animations.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/brands.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/linkstack/css/skeleton-auto.css')); ?>">
<?php endif; ?>
<style>.container{word-break: break-word;}</style>
</head>
<body>

<?php if(theme('enable_custom_code') == "true" and theme('enable_custom_body') == "true" and env('ALLOW_CUSTOM_CODE_IN_THEMES') == 'true'): ?><?php echo $__env->make($GLOBALS['themeName'] . '.extra.custom-body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>

<?php if($info->theme != '' and $info->theme != 'default'): ?>
    <!-- Enables parallax background animations -->
    <div class="background-container">
    <section class="parallax-background">
      <div id="object1" class="object1"></div>
      <div id="object2" class="object2"></div>
      <div id="object3" class="object3"></div>
      <div id="object4" class="object4"></div>
      <div id="object5" class="object5"></div>
      <div id="object6" class="object6"></div>
      <div id="object7" class="object7"></div>
      <div id="object8" class="object8"></div>
      <div id="object9" class="object9"></div>
      <div id="object10" class="object10"></div>
      <div id="object11" class="object11"></div>
      <div id="object12" class="object12"></div>
    </section>
    </div>
    <!-- End of parallax background animations -->
<?php endif; ?>

<?php echo $__env->make('components.favicon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.favicon-extension', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php ////begin share button//// ?>

<?php if(config('advanced-config.display_share_button') != ''): ?>

   <?php if(config('advanced-config.display_share_button') == 'false'): ?>
   <?php $ShowShrBtn = 'false'; ?>
   <?php elseif(config('advanced-config.display_share_button') == 'user'): ?>
       <?php if($littlelink_names = Auth::user()->littlelink_name): ?>
       <?php $ShowShrBtn = 'true'; ?>
       <?php else: ?>
       <?php $ShowShrBtn = 'false'; ?>
       <?php endif; ?>
   <?php else: ?>
   <?php $ShowShrBtn = 'true'; ?>
   <?php endif; ?>

<?php else: ?>
<?php $ShowShrBtn = 'true'; ?>
<?php endif; ?>

<?php if($ShowShrBtn == 'true' and UserData::getData($userinfo->id, 'disable-sharebtn') != "true"): ?>

<script><?php echo file_get_contents(base_path("assets/linkstack/js/jquery.min.js")); ?></script>
<div align="right" class="sharediv">
  <div>
    <span class="sharebutton button-hover icon-hover share-button" data-share="<?php echo e(url()->current()); ?>" tabindex="0" role="button" aria-label="<?php echo e(__('messages.Share this page')); ?>">
      <i style="color: black;" class="fa-solid fa-share sharebutton-img share-icon hvr-icon"></i>
      <span class="sharebutton-mb"><?php echo e(__('messages.Share')); ?></span>
    </span>
  </div>
</div>
<span class="copy-icon" tabindex="0" role="button" aria-label="<?php echo e(__('messages.Copy URL to clipboard')); ?>">
</span>

<script>
  const shareButtons = document.querySelectorAll('.share-button');
  shareButtons.forEach(button => {
    button.addEventListener('click', () => {
      const valueToShare = button.dataset.share;
      if (navigator.share) {
        navigator.share({
          title: "<?php echo e(__('messages.Share this page')); ?>",
          url: valueToShare
        })
        .catch(err => console.error('Error:', err));
      } else {
        navigator.clipboard.writeText(valueToShare)
        .then(() => {
          alert("<?php echo e(__('messages.URL has been copied to your clipboard!')); ?>");
        })
        .catch(err => {
          alert('Error', err);
        });
      }
    });
  });
</script>


<?php endif; ?>
<?php ////end share button//// ?>

  <div class="container">
    <div class="row">
      <div class="column" style="margin-top: 5%">
        <!-- Your Image Here -->
          <?php if(file_exists(base_path(findAvatar($userinfo->id)))): ?>
          <img alt="avatar" class="rounded-avatar fadein" src="<?php echo e(url(findAvatar($userinfo->id))); ?>" height="128px" width="128px" style="object-fit: cover;">
          <?php elseif(file_exists(base_path("assets/linkstack/images/").findFile('avatar'))): ?>
          <img alt="avatar" class="fadein" src="<?php echo e(url("assets/linkstack/images/")."/".findFile('avatar')); ?>" height="128px" width="128px" style="object-fit: cover;">
          <?php else: ?>
          <img alt="avatar" class="fadein" src="<?php echo e(asset('assets/linkstack/images/logo.svg')); ?>" height="128px" style="width:auto;min-width:128px;object-fit: cover;">
          <?php endif; ?>

        <!-- Your Name -->
        <h1 class="fadein"><?php echo e($info->name); ?><?php if(($userinfo->role == 'vip' or $userinfo->role == 'admin') and theme('disable_verification_badge') != "true" and env('HIDE_VERIFICATION_CHECKMARK') != true and UserData::getData($userinfo->id, 'checkmark') != false): ?><span title="<?php echo e(__('messages.Verified user')); ?>"><?php echo $__env->make('components.verify-svg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?></span></h1>

        <!-- Short Bio -->
        <style>.description-parent * {margin-bottom: 1em;}.description-parent {padding-bottom: 30px;}</style>
        <center><div class="fadein description-parent"><p class="fadein"><?php if(env('ALLOW_USER_HTML') === true): ?><?php echo $info->littlelink_description; ?><?php else: ?><?php echo e($info->littlelink_description); ?><?php endif; ?></p></div></center>
        
        <!-- Icons -->
        <?php $icons = DB::table('links')->where('user_id', $userinfo->id)->where('button_id', 94)->get(); ?>
        <?php if(count($icons) > 0): ?>
        <div class="row fadein social-icon-div">
        <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="social-hover social-link" href="<?php echo e(route('clickNumber') . '/' . $icon->id. "?" . $icon->link); ?>" title="<?php echo e(ucfirst($icon->title)); ?>" aria-label="<?php echo e(ucfirst($icon->title)); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?>><i class="social-icon fa-brands fa-<?php echo e($icon->title); ?>"></i></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		

        <!-- Buttons -->
        <?php $initial = 1; ?>

<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $linkName = str_replace('default ','',$link->title) ?>
    <?php switch($link->name):
        case ('icon'): ?>
            <?php break; ?>
        <?php case ('phone'): ?>
        <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-default button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e(route('clickNumber') . '/' . $link->id . "?" . $link->link); ?>"><img alt="<?php echo e($link->name); ?>" class="icon hvr-icon" src="<?php if(theme('use_custom_icons') == "true"): ?><?php echo e(url('themes/' . $GLOBALS['themeName'] . '/extra/custom-icons')); ?>/phone<?php echo e(theme('custom_icon_extension')); ?> <?php else: ?><?php echo e(asset('\/assets/linkstack/icons\/')); ?>phone.svg <?php endif; ?>"></i><?php echo e($link->title); ?></a></div>
            <?php break; ?>
        <?php case ('default email'): ?>
        <?php case ('default email_alt'): ?>
        <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-default button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e(route('clickNumber') . '/' . $link->id . "?" . $link->link); ?>"><img alt="email" class="icon hvr-icon" src="<?php if(theme('use_custom_icons') == "true"): ?><?php echo e(url('themes/' . $GLOBALS['themeName'] . '/extra/custom-icons')); ?>/email<?php echo e(theme('custom_icon_extension')); ?> <?php else: ?><?php echo e(asset('\/assets/linkstack/icons\/')); ?>email.svg <?php endif; ?>"></i><?php echo e($link->title); ?></a></div>
            <?php break; ?>
        <?php case ('buy me a coffee'): ?>
        <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-coffee button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e(route('clickNumber') . '/' . $link->id . "?" . $link->link); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><img alt="<?php echo e($link->name); ?>" class="icon hvr-icon" src="<?php if(theme('use_custom_icons') == "true"): ?><?php echo e(url('themes/' . $GLOBALS['themeName'] . '/extra/custom-icons')); ?>/coffee<?php echo e(theme('custom_icon_extension')); ?> <?php else: ?><?php echo e(asset('\/assets/linkstack/icons\/')); ?>coffee.svg <?php endif; ?>">Buy me a Coffee</a></div>
            <?php break; ?>
        <?php case ('mastodon'): ?>
        <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-<?php echo e($link->name); ?> button button-hover icon-hover" rel="me noopener noreferrer nofollow" href="<?php echo e(route('clickNumber') . '/' . $link->id . "?" . $link->link); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><img alt="<?php echo e($link->name); ?>" class="icon hvr-icon" src="<?php if(theme('use_custom_icons') == "true"): ?><?php echo e(url('themes/' . $GLOBALS['themeName'] . '/extra/custom-icons')); ?>/<?php echo e($linkName); ?><?php echo e(theme('custom_icon_extension')); ?> <?php else: ?><?php echo e(asset('\/assets/linkstack/icons\/') . "mastodon"); ?>.svg <?php endif; ?>"><?php echo e($link->title); ?></a></div>
            <?php break; ?>
               <?php case ('space'): ?>
               <?php $title = $link->title; if (is_numeric($title)) { echo str_repeat("<br>", $title < 10 ? $title : 10); } else { echo "<br><br><br>"; } ?>
            <?php break; ?>
        <?php case ('heading'): ?>
        <div class="fadein"><h2><?php echo e($link->title); ?></h2></div>
            <?php break; ?>
        <?php case ('text'): ?>
        <div class="fadein"><span style=""><?php if(env('ALLOW_USER_HTML') === true): ?><?php echo $link->title; ?><?php else: ?><?php echo e($link->title); ?><?php endif; ?></span></div>
            <?php break; ?>
        <?php case ('vcard'): ?>
            <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-default button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e(route('vcard') . '/' . $link->id); ?>"><img alt="<?php echo e($link->name); ?>" class="icon hvr-icon" src="<?php if(theme('use_custom_icons') == "true"): ?><?php echo e(url('themes/' . $GLOBALS['themeName'] . '/extra/custom-icons')); ?>/vcard<?php echo e(theme('custom_icon_extension')); ?> <?php else: ?><?php echo e(asset('\/assets/linkstack/icons\/')); ?>vcard.svg <?php endif; ?>"></i><?php echo e($link->title); ?></a></div>
                <?php break; ?>
        <?php case ('custom'): ?>
          <?php if($link->custom_css === "" or $link->custom_css === "NULL" or (theme('allow_custom_buttons') == "false")): ?>
           <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-<?php echo e($link->name); ?> button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e(route('clickNumber') . '/' . $link->id . "?" . $link->link); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><i style="color: <?php echo e($link->custom_icon); ?>" class="icon hvr-icon fa <?php echo e($link->custom_icon); ?>"></i><?php echo e($link->title); ?></a></div>
              <?php break; ?>
           <?php elseif($link->custom_css != ""): ?>
           <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-hover icon-hover" style="<?php echo e($link->custom_css); ?>" rel="noopener noreferrer nofollow" href="<?php echo e(route('clickNumber') . '/' . $link->id . "?" . $link->link); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><i style="color: <?php echo e($link->custom_icon); ?>" class="icon hvr-icon fa <?php echo e($link->custom_icon); ?>"></i><?php echo e($link->title); ?></a></div>
              <?php break; ?>
            <?php endif; ?>
        <?php case ('custom_website'): ?>
           <?php if($link->custom_css === "" or $link->custom_css === "NULL" or (theme('allow_custom_buttons') == "false")): ?>
             <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-custom_website button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e(route('clickNumber') . '/' . $link->id . "?" . $link->link); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><img alt="<?php echo e($link->name); ?>" class="icon hvr-icon" src="<?php if(file_exists(base_path("assets/favicon/icons/").localIcon($link->id))): ?><?php echo e(url('assets/favicon/icons/'.localIcon($link->id))); ?><?php else: ?><?php echo e(getFavIcon($link->id)); ?><?php endif; ?>" onerror="this.onerror=null; this.src='<?php echo e(asset('assets/linkstack/icons/website.svg')); ?>';"><?php echo e($link->title); ?></a></div>
               <?php break; ?>
           <?php elseif($link->custom_css != ""): ?>
            <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-hover icon-hover" style="<?php echo e($link->custom_css); ?>" rel="noopener noreferrer nofollow" href="<?php echo e(route('clickNumber') . '/' . $link->id . "?" . $link->link); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><img alt="<?php echo e($link->name); ?>" class="icon hvr-icon" src="<?php if(file_exists(base_path("assets/favicon/icons/").localIcon($link->id))): ?><?php echo e(url('assets/favicon/icons/'.localIcon($link->id))); ?><?php else: ?><?php echo e(getFavIcon($link->id)); ?><?php endif; ?>" onerror="this.onerror=null; this.src='<?php echo e(asset('assets/linkstack/icons/website.svg')); ?>';"><?php echo e($link->title); ?></a></div>
             <?php break; ?>
           <?php endif; ?>
           <?php default: ?>
        <?php include base_path('config/button-names.php'); $newLinkName = $linkName; $isNewName = "false"; foreach($buttonNames as $key => $value) { if($newLinkName == $key) { $newLinkName = $value; $isNewName = "true"; }} ?>
        <div style="--delay: <?php echo e($initial++); ?>s" class="button-entrance"><a class="button button-<?php echo e($link->name); ?> button button-hover icon-hover" rel="noopener noreferrer nofollow" href="<?php echo e(route('clickNumber') . '/' . $link->id . "?" . $link->link); ?>" <?php if(theme('open_links_in_same_tab') != "true"): ?>target="_blank"<?php endif; ?> ><img alt="<?php echo e($link->name); ?>" class="icon hvr-icon" src="<?php if(theme('use_custom_icons') == "true"): ?><?php echo e(url('themes/' . $GLOBALS['themeName'] . '/extra/custom-icons')); ?>/<?php echo e($link->name); ?><?php echo e(theme('custom_icon_extension')); ?> <?php else: ?><?php echo e(asset('\/assets/linkstack/icons\/') . $link->name); ?>.svg <?php endif; ?>"><?php if($isNewName == "true"): ?><?php echo e(ucfirst($newLinkName)); ?><?php else: ?><?php echo e(ucfirst($newLinkName)); ?><?php endif; ?></a></div>
    <?php endswitch; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
      </div>
    </div>
  </div>

<?php if(theme('enable_custom_code') == "true" and theme('enable_custom_body_end') == "true" and env('ALLOW_CUSTOM_CODE_IN_THEMES') == 'true'): ?><?php echo $__env->make($GLOBALS['themeName'] . '.extra.custom-body-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>

</body>
</html><?php /**PATH /htdocs/resources/views/littlelink.blade.php ENDPATH**/ ?>