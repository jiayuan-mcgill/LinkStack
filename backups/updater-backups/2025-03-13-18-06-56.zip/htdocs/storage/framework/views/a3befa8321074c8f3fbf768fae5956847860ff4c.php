<?php use App\Models\Page; ?>
<style>
@supports (-webkit-appearance: none) or (-moz-appearance: none) {
  input[type=checkbox],
input[type=radio] {
    --active: var(--bs-primary);
    --active-inner: #fff;
    --focus: 2px var(--bs-primary);
    --border: #BBC1E1;
    --border-hover: var(--bs-primary);
    --background: #fff;
    --disabled: #F6F8FF;
    --disabled-inner: #E1E6F9;
    -webkit-appearance: none;
    -moz-appearance: none;
    height: 21px;
    outline: none;
    display: inline-block;
    vertical-align: top;
    position: relative;
    margin: 0;
    cursor: pointer;
    border: 1px solid var(--bc, var(--border));
    background: var(--b, var(--background));
    transition: background 0.3s, border-color 0.3s, box-shadow 0.2s;
  }
  input[type=checkbox]:after,
input[type=radio]:after {
    content: "";
    display: block;
    left: 0;
    top: 0;
    position: absolute;
    transition: transform var(--d-t, 0.3s) var(--d-t-e, ease), opacity var(--d-o, 0.2s);
  }
  input[type=checkbox]:checked,
input[type=radio]:checked {
    --b: var(--active);
    --bc: var(--active);
    --d-o: .3s;
    --d-t: .6s;
    --d-t-e: cubic-bezier(.2, .85, .32, 1.2);
  }
  input[type=checkbox]:disabled,
input[type=radio]:disabled {
    --b: var(--disabled);
    cursor: not-allowed;
    opacity: 0.9;
  }
  input[type=checkbox]:disabled:checked,
input[type=radio]:disabled:checked {
    --b: var(--disabled-inner);
    --bc: var(--border);
  }
  input[type=checkbox]:disabled + label,
input[type=radio]:disabled + label {
    cursor: not-allowed;
  }
  input[type=checkbox]:hover:not(:checked):not(:disabled),
input[type=radio]:hover:not(:checked):not(:disabled) {
    --bc: var(--border-hover);
  }
  input[type=checkbox]:focus,
input[type=radio]:focus {
    box-shadow: 0 0 0 var(--focus);
  }
  input[type=checkbox]:not(.switch),
input[type=radio]:not(.switch) {
    width: 21px;
  }
  input[type=checkbox]:not(.switch):after,
input[type=radio]:not(.switch):after {
    opacity: var(--o, 0);
  }
  input[type=checkbox]:not(.switch):checked,
input[type=radio]:not(.switch):checked {
    --o: 1;
  }
  input[type=checkbox] + label,
input[type=radio] + label {
    font-size: 14px;
    line-height: 21px;
    display: inline-block;
    vertical-align: top;
    cursor: pointer;
    margin-left: 4px;
  }

  input[type=checkbox]:not(.switch) {
    border-radius: 7px;
  }
  input[type=checkbox]:not(.switch):after {
    width: 5px;
    height: 9px;
    border: 2px solid var(--active-inner);
    border-top: 0;
    border-left: 0;
    left: 7px;
    top: 4px;
    transform: rotate(var(--r, 20deg));
  }
  input[type=checkbox]:not(.switch):checked {
    --r: 43deg;
  }
  input[type=checkbox].switch {
    width: 38px;
    border-radius: 11px;
  }
  input[type=checkbox].switch:after {
    left: 2px;
    top: 2px;
    border-radius: 50%;
    width: 15px;
    height: 15px;
    background: var(--ab, var(--border));
    transform: translateX(var(--x, 0));
  }
  input[type=checkbox].switch:checked {
    --ab: var(--active-inner);
    --x: 17px;
  }
  input[type=checkbox].switch:disabled:not(:checked):after {
    opacity: 0.6;
  }

  input[type=radio] {
    border-radius: 50%;
  }
  input[type=radio]:after {
    width: 19px;
    height: 19px;
    border-radius: 50%;
    background: var(--active-inner);
    opacity: 0;
    transform: scale(var(--s, 0.7));
  }
  input[type=radio]:checked {
    --s: .5;
  }
}
.txt-label{
    color: white;
    padding-left: 5px;
    font-size: 200%;
    position: relative;
}
.toggle-btn{
    padding-left: 20px;
}
.ch2{
    padding-top: 60px;
}
.nav-link{
  color: var(--bs-primary);
}
</style>

<?php 
function toggle($key){
    $configNames = json_decode(file_get_contents(base_path('config/config-legends.json')));
	echo '
    <form id="'.$key.'-form" action="'.route('editConfig').'" enctype="multipart/form-data" method="post">
	<div class="form-group col-lg-8">
	<input value="toggle" name="type" style="display:none;" type="text" class="form-control form-control-lg" required>
	<input value="'.$key.'" name="entry" style="display:none;" type="text" class="form-control form-control-lg" required>
	<h5 style="margin-top:50px">'; echo __('messages.'.$key.'.title'); echo '</h5>
    <p class="text-muted">'; echo __('messages.'.$key.'.description'); echo '</p>
	<div class="input-group">
	<div class="mb-3 form-check form-switch toggle-btn"><input name="toggle" class="switch toggle-btn" type="checkbox" id="'.$key.'"'; if(EnvEditor::getKey($key) == 'false'){echo '/>';}else{echo 'checked>';} echo '<label for="'.$key.'" class="form-check-label">'.__('messages.Enable').'</label></div>
	</div></div>
    <input type="hidden" name="_token" value="'.csrf_token().'">
    <script type="text/javascript">
document.getElementById("'.$key.'-form").addEventListener("change", function() { 
    this.submit(); 
});
</script>
    </form>
	';
}
?>


<?php 
function toggle2($key){
    $configNames = json_decode(file_get_contents(base_path('config/config-legends.json')));
	echo '
    <form id="'.$key.'-form" action="'.route('editConfig').'" enctype="multipart/form-data" method="post">
	<div class="form-group col-lg-8">
	<input value="toggle2" name="type" style="display:none;" type="text" class="form-control form-control-lg" required>
	<input value="'.$key.'" name="entry" style="display:none;" type="text" class="form-control form-control-lg" required>
	<h5 style="margin-top:50px">'; echo __('messages.'.$key.'.title'); echo '</h5>
    <p class="text-muted">'; echo __('messages.'.$key.'.description'); echo '</p>
	<div class="input-group">
	<div class="mb-3 form-check form-switch toggle-btn"><input name="toggle" class="switch toggle-btn" type="checkbox" id="'.$key.'"'; if(EnvEditor::getKey($key) == 'auth'){echo '/>';}else{echo 'checked>';} echo '<label for="'.$key.'" class="form-check-label">'.__('messages.Enable').'</label></div>
	</div></div>
    <input type="hidden" name="_token" value="'.csrf_token().'">
    <script type="text/javascript">
document.getElementById("'.$key.'-form").addEventListener("change", function() { 
    this.submit(); 
});
</script>
    </form>
	';
}
?>


<?php 
function text($key){
    $configNames = json_decode(file_get_contents(base_path('config/config-legends.json')));
    $configValue = str_replace('"', "", EnvEditor::getKey($key));
	echo '
    <form id="'.$key.'-form" action="'.route('editConfig').'" enctype="multipart/form-data" method="post">
    <div class="form-group col-lg-8">
    <input value="text" name="type" style="display:none;" type="text" class="form-control form-control-lg" required>
    <input value="'.$key.'" name="entry" style="display:none;" type="text" class="form-control form-control-lg" required>
	<h5 style="margin-top:50px">'; echo __('messages.'.$key.'.title'); echo '</h5>
    <p class="text-muted">'; echo __('messages.'.$key.'.description'); echo '</p>
    <div class="input-group">
    <input type="text" class="form-control form-control-lg" style="border-radius:.25rem;max-width:600px" class="form-control" name="value" value="'.$configValue.'" required>';  echo '
    <input type="hidden" name="_token" value="'.csrf_token().'">
	<button  type="submit" class="btn btn-primary">'.__('messages.Apply').'</button>
    </div></div>
    </form>
	';
}
?>


<a name="Application"><h2 class="ch2"><?php echo e(__('messages.Application')); ?></h2></a>

<?php if(!config('linkstack.single_user_mode')): ?>
<?php echo e(toggle('ALLOW_REGISTRATION')); ?>



<?php echo e(toggle2('REGISTER_AUTH')); ?>



<?php echo e(toggle('MANUAL_USER_VERIFICATION')); ?>

<?php endif; ?>

<?php echo e(text('ADMIN_EMAIL')); ?>



<?php $configValue2 = str_replace('"', "", EnvEditor::getKey('HOME_URL')); ?>
<form id="home-url-form" action="<?php echo e(route('editConfig')); ?>" enctype="multipart/form-data" method="post">
<div class="form-group col-lg-8">
<input value="homeurl" name="type" style="display:none;" type="text" class="form-control form-control-lg" required>
<input value="HOME_URL" name="entry" style="display:none;" type="text" class="form-control form-control-lg" required>
<h5 style="margin-top:50px"><?php echo e(__('messages.HOME_URL.title')); ?></h5>
<p class="text-muted"><?php echo e(__('messages.HOME_URL.description')); ?></p>
<div class="input-group">

<select style="max-width:600px" class="form-control" name="value">
<?php if($configValue2 != ''): ?><option><?php echo e($configValue2); ?></option><?php endif; ?>
<?php if($configValue2 != 'default'): ?><option value="default"><?php echo e(__('messages.default')); ?></option><?php endif; ?>
<?php $users = DB::table('users')->where('littlelink_name', '!=', '')->get();
foreach($users as $user){if($user->littlelink_name != $configValue2){echo '<option>' . $user->littlelink_name . '</option>';}} ?>
</select>

</div></div>
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<script type="text/javascript">document.getElementById("home-url-form").addEventListener("change", function() { this.submit(); });</script>
</form>



<?php echo e(toggle('FORCE_HTTPS')); ?>



<?php echo e(text('APP_NAME')); ?>



<?php echo e(toggle('HIDE_VERIFICATION_CHECKMARK')); ?>



<a name="Panel-settings"><h2 class="ch2"><?php echo e(__('messages.Panel settings')); ?></h2></a>

<?php echo e(toggle('NOTIFY_EVENTS')); ?>



<?php echo e(toggle('NOTIFY_UPDATES')); ?>



<?php echo e(toggle('ENABLE_BUTTON_EDITOR')); ?>



<?php echo e(toggle('USE_THEME_PREVIEW_IFRAME')); ?>



<?php echo e(toggle('ALLOW_CUSTOM_BACKGROUNDS')); ?>



<a name="Security"><h2 class="ch2"><?php echo e(__('messages.Security')); ?></h2></a>


<?php echo e(toggle('ALLOW_USER_HTML')); ?>



<?php echo e(toggle('ALLOW_CUSTOM_CODE_IN_THEMES')); ?>



<?php echo e(toggle('ENABLE_THEME_UPDATER')); ?>



<?php echo e(toggle('ALLOW_USER_EXPORT')); ?>



<?php echo e(toggle('ALLOW_USER_IMPORT')); ?>




<a name="Advanced"><h2 class="ch2"><?php echo e(__('messages.Advanced')); ?></h2></a>

<?php echo e(toggle('JOIN_BETA')); ?>



<form id="MAINTENANCE_MODE-form" action="<?php echo e(route('editConfig')); ?>" enctype="multipart/form-data" method="post">
<div class="form-group col-lg-8">
<input value="maintenance" name="type" style="display:none;" type="text" class="form-control form-control-lg" required>
<input value="MAINTENANCE_MODE" name="entry" style="display:none;" type="text" class="form-control form-control-lg" required>
<h5 style="margin-top:50px"><?php echo e(__('messages.MAINTENANCE_MODE.title')); ?></h5>
<p class="text-muted"><?php echo e(__('messages.MAINTENANCE_MODE.description')); ?></p>
<div class="input-group">
<div class="mb-3 form-check form-switch toggle-btn"><input name="toggle" class="switch toggle-btn" type="checkbox" id="MAINTENANCE_MODE" <?php if(EnvEditor::getKey('MAINTENANCE_MODE') == 'true' or file_exists(base_path("storage/MAINTENANCE"))){echo 'checked>';}else{echo '/>';} ?><label for="MAINTENANCE_MODE" class="form-check-label"><?php echo e(__('messages.Enable')); ?></label></div>
</div></div>
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<script type="text/javascript">
document.getElementById("MAINTENANCE_MODE-form").addEventListener("change", function() { 
    this.submit(); 
});
</script>
</form>



<?php echo e(toggle('SKIP_UPDATE_BACKUP')); ?>



<?php echo e(toggle('CUSTOM_META_TAGS')); ?>



<?php if(!config('linkstack.single_user_mode')): ?>
<?php echo e(toggle('ENABLE_SOCIAL_LOGIN')); ?>

<?php endif; ?>


<?php echo e(toggle('FORCE_ROUTE_HTTPS')); ?>




<a name="SMTP"><h2 class="ch2"><?php echo e(__('messages.SMTP')); ?></h2></a>
<form id="smtp-form" action="<?php echo e(route('editConfig')); ?>" enctype="multipart/form-data" method="post">
<div class="form-group col-lg-8">
<input value="smtp" name="type" style="display:none;" type="text" class="form-control form-control-lg" required>
<input value="smtp" name="entry" style="display:none;" type="text" class="form-control form-control-lg" required>
<h5 style="margin-top:50px"><?php echo e(__('messages.SMTP.title')); ?></h5>
<p class="text-muted"><?php echo e(__('messages.SMTP.description')); ?><br><?php echo e(__('messages.SMTP.description.alt')); ?></p>
<div class="input-group">
<div class="mb-3 form-check form-switch toggle-btn"><input name="toggle" class="switch toggle-btn" type="checkbox" id="toggle-smtp" <?php if(env('MAIL_MAILER') != 'built-in'){echo '/>';}else{echo 'checked>';} ?> <label for="toggle-smtp" class="form-check-label"><?php echo e(__('messages.Enable')); ?></label></div>
</div></div>
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<div style="max-width: 600px; padding-left: 20px;">
<br><h5><?php echo e(__('messages.Custom SMTP server:')); ?></h5>
<label style="margin-top:15px"><?php echo e(__('messages.Host')); ?></label>
<input type="text" class="form-control form-control-lg" class="form-control form-control-lg" name="MAIL_HOST" value="<?php echo e(env('MAIL_HOST')); ?>" />
<label style="margin-top:15px"><?php echo e(__('messages.Port')); ?></label>
<input type="text" class="form-control form-control-lg" class="form-control form-control-lg" name="MAIL_PORT" value="<?php echo e(env('MAIL_PORT')); ?>" />
<label style="margin-top:15px"><?php echo e(__('messages.Username')); ?></label>
<input type="text" class="form-control form-control-lg" class="form-control form-control-lg" name="MAIL_USERNAME" value="<?php echo e(env('MAIL_USERNAME')); ?>" />
<label style="margin-top:15px"><?php echo e(__('messages.Password')); ?></label>
<input type="password" class="form-control" name="MAIL_PASSWORD" value="<?php echo e(env('MAIL_PASSWORD')); ?>" />
<label style="margin-top:15px"><?php echo e(__('messages.Encryption type')); ?></label>
<input type="text" class="form-control form-control-lg" class="form-control form-control-lg" name="MAIL_ENCRYPTION" value="<?php echo e(env('MAIL_ENCRYPTION')); ?>" />
<label style="margin-top:15px"><?php echo e(__('messages.From address')); ?></label>
<input type="text" class="form-control form-control-lg" class="form-control form-control-lg" name="MAIL_FROM_ADDRESS" value="<?php echo e(env('MAIL_FROM_ADDRESS')); ?>" />
<button type="submit" class="btn btn-primary mt-4"><?php echo e(__('messages.Apply changes')); ?></button>
</div>
</form>

<div class="form-group col-lg-8">
  <br><br><h5><?php echo e(__('messages.Test E-Mail setup:')); ?></h5>
  <?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php elseif(session('fail')): ?>
  <div class="alert alert-danger">
      <?php echo e(session('fail')); ?>

  </div>
<?php endif; ?>
</div>
<a href="<?php echo e(route('SendTestMail')); ?>"><button class="btn btn-gray"><?php echo e(__('messages.Send Test E-Mail')); ?></button></a>




<a name="Footer"><h2 class="ch2"><?php echo e(__('messages.Footer links')); ?></h2></a>

<?php echo e(toggle('DISPLAY_FOOTER')); ?>


<?php echo e(toggle('DISPLAY_CREDIT')); ?>


<?php echo e(toggle('DISPLAY_CREDIT_FOOTER')); ?>


<?php echo e(toggle('DISPLAY_FOOTER_HOME')); ?>

<?php echo e(text('TITLE_FOOTER_HOME')); ?>


<?php
    $configNames = json_decode(file_get_contents(base_path('config/config-legends.json')));
    $configValue = str_replace('"', "", EnvEditor::getKey('HOME_FOOTER_LINK'));
?>
    <form id="HOME_FOOTER_LINK-form" action="<?php echo e(route('editConfig')); ?>" enctype="multipart/form-data" method="post">
    <div class="form-group col-lg-8">
    <input value="text" name="type" style="display:none;" type="text" class="form-control form-control-lg" required>
    <input value="HOME_FOOTER_LINK" name="entry" style="display:none;" type="text" class="form-control form-control-lg" required>
	<h5 style="margin-top:50px"><?php echo __('messages.HOME_FOOTER_LINK.title'); ?></h5>
    <p class="text-muted"><?php echo __('messages.HOME_FOOTER_LINK.description'); ?></p>
    <div class="input-group">
    <input type="url" style="border-radius:.25rem;max-width:600px" class="form-control" name="value" value="<?php echo e($configValue); ?>">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<button  type="submit" class="btn btn-primary"><?php echo e(__('messages.Apply')); ?></button>
    </div></div>
    </form>

<?php echo e(toggle('DISPLAY_FOOTER_TERMS')); ?>

<?php echo e(text('TITLE_FOOTER_TERMS')); ?>


<?php echo e(toggle('DISPLAY_FOOTER_PRIVACY')); ?>

<?php echo e(text('TITLE_FOOTER_PRIVACY')); ?>


<?php echo e(toggle('DISPLAY_FOOTER_CONTACT')); ?>

<?php echo e(text('TITLE_FOOTER_CONTACT')); ?>





<a name="Debug"><h2 class="ch2"><?php echo e(__('messages.Debug')); ?></h2></a>
<form id="debug-form" action="<?php echo e(route('editConfig')); ?>" enctype="multipart/form-data" method="post">
<div class="form-group col-lg-8">
<input value="debug" name="type" style="display:none;" type="text" class="form-control form-control-lg" required>
<input value="debug" name="entry" style="display:none;" type="text" class="form-control form-control-lg" required>
<h5 style="margin-top:50px"><?php echo e(__('messages.Debug.title')); ?></h5>
<p class="text-muted"><?php echo e(__('messages.Debug.description')); ?></p>
<div class="input-group">
<div class="mb-3 form-check form-switch toggle-btn"><input name="toggle" class="switch toggle-btn" type="checkbox" id="toggle-debug" <?php if(EnvEditor::getKey('APP_DEBUG') == 'false'){echo '/>';}else{echo 'checked>';} ?> <label for="toggle-debug" class="form-check-label"><?php echo e(__('messages.Enable')); ?></label></div>
</div></div>
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<script type="text/javascript">document.getElementById("debug-form").addEventListener("change", function() { this.submit(); });</script>
</form>



<a name="Language"><h2 class="ch2"><?php echo e(__('messages.Language')); ?></h2></a>
<?php $configValue2 = str_replace('"', "", EnvEditor::getKey('LOCALE')); ?>
<form id="language-form" action="<?php echo e(route('editConfig')); ?>" enctype="multipart/form-data" method="post">
    <div class="form-group col-lg-8">
        <input value="homeurl" name="type" style="display:none;" type="text" class="form-control form-control-lg" required>
        <input value="LOCALE" name="entry" style="display:none;" type="text" class="form-control form-control-lg" required>
        <h5 style="margin-top:50px"><?php echo e(__('messages.LOCALE.title')); ?></h5>
        <p class="text-muted"><?php echo e(__('messages.LOCALE.description')); ?></p>
        <div class="input-group">
            <select style="max-width:600px" class="form-control" name="value">
                <?php if($configValue2 != ''): ?>
                    <option><?php echo e($configValue2); ?></option>
                <?php endif; ?>
                <?php
                try {
                    $langFolders = array_filter(glob(base_path('resources/lang') . '/*'), 'is_dir');
                } catch (\Exception $e) {
                    $langFolders = [];
                }

                foreach($langFolders as $folder) {
                    $folderName = basename($folder);
                    if ($folderName != $configValue2) {
                        echo '<option>' . $folderName . '</option>';
                    }
                }
                ?>
            </select>
        </div>
    </div>
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <script type="text/javascript">
        document.getElementById("language-form").addEventListener("change", function() {
            this.submit();
        });
    </script>
</form>



<br><br><br><br><br>

<script src="<?php echo e(asset('assets/external-dependencies/jquery-3.4.1.min.js')); ?>"></script>

<script type="text/javascript">
$(document).ready(function () {

    if (localStorage.getItem("my_app_name_here-quote-scroll") != null) {
        $(window).scrollTop(localStorage.getItem("my_app_name_here-quote-scroll"));
    }

    $(window).on("scroll", function() {
        localStorage.setItem("my_app_name_here-quote-scroll", $(window).scrollTop());
    });

  });
</script>

<?php /**PATH /htdocs/resources/views/components/config/config.blade.php ENDPATH**/ ?>