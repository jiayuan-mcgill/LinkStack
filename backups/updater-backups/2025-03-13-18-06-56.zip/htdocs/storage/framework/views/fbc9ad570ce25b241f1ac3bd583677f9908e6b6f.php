<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">

<?php echo $__env->make('layouts.analytics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <script src="<?php echo e(asset('assets/js/detect-dark-mode.js')); ?>"></script>

		<?php if(file_exists(base_path("assets/linkstack/images/").findFile('favicon'))): ?>
		<link rel="icon" type="image/png" href="<?php echo e(asset('assets/linkstack/images/'.findFile('favicon'))); ?>">
		<?php else: ?>
		<link rel="icon" type="image/svg+xml" href="<?php echo e(asset('assets/linkstack/images/logo.svg')); ?>">
		<?php endif; ?>

        <title><?php echo e(config('app.name')); ?></title>

      <!-- Fonts -->
      <?php echo $__env->make('layouts.fonts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <!-- Library / Plugin Css Build -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/core/libs.min.css')); ?>" />
      
      <!-- Aos Animation Css -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/aos/dist/aos.css')); ?>" />
      
      <!-- Hope Ui Design System Css -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/hope-ui.min.css?v=2.0.0')); ?>" />
      
      <!-- Custom Css -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.min.css?v=2.0.0')); ?>" />
      
      <!-- Dark Css -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/dark.min.css')); ?>" />
      
      <!-- Customizer Css -->
            <?php if(file_exists(base_path("assets/dashboard-themes/dashboard.css"))): ?>
      <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard-themes/dashboard.css')); ?>" />
      <?php else: ?>
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/customizer.min.css')); ?>" />
      <?php endif; ?>
      
      <!-- RTL Css -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/rtl.min.css')); ?>" />

      <!-- Scripts -->
      <script src="<?php echo e(asset('assets/js/app.js')); ?>" defer></script>

	  <link rel="stylesheet" href="<?php echo e(asset('assets/external-dependencies/bootstrap-icons.css')); ?>">
    </head>
    <body>

            <?php echo e($slot); ?>


    </body>

    <!-- Library Bundle Script -->
    <script src="<?php echo e(asset('assets/js/core/libs.min.js')); ?>"></script>
    
    <!-- External Library Bundle Script -->
    <script src="<?php echo e(asset('assets/js/core/external.min.js')); ?>"></script>
    
    <!-- Widgetchart Script -->
    <script src="<?php echo e(asset('assets/js/charts/widgetcharts.js')); ?>"></script>
    
    <!-- mapchart Script -->
    <script src="<?php echo e(asset('assets/js/charts/vectore-chart.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/charts/dashboard.js')); ?>" ></script>
    
    <!-- fslightbox Script -->
    <script src="<?php echo e(asset('assets/js/plugins/fslightbox.js')); ?>"></script>
    
    <!-- Settings Script -->
    <script src="<?php echo e(asset('assets/js/plugins/setting.js')); ?>"></script>
    
    <!-- Slider-tab Script -->
    <script src="<?php echo e(asset('assets/js/plugins/slider-tabs.js')); ?>"></script>
    
    <!-- Form Wizard Script -->
    <script src="<?php echo e(asset('assets/js/plugins/form-wizard.js')); ?>"></script>
    
    <!-- AOS Animation Plugin-->
    <script src="<?php echo e(asset('assets/vendor/aos/dist/aos.js')); ?>"></script>
    
    <!-- App Script -->
    <script src="<?php echo e(asset('assets/js/hope-ui.js')); ?>" defer></script>
    
    <!-- Flatpickr Script -->
    <script src="<?php echo e(asset('assets/vendor/flatpickr/dist/flatpickr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/flatpickr.js')); ?>" defer></script>
    
    <script src="<?php echo e(asset('assets/js/plugins/prism.mini.js')); ?>"></script>

</html>
<?php /**PATH /htdocs/resources/views/layouts/guest.blade.php ENDPATH**/ ?>