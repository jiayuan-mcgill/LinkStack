

<?php $__env->startSection('content'); ?>

<div class="conatiner-fluid content-inner mt-n5 py-0">
  <div class="row">   


      <div class="col-lg-12">
          <div class="card   rounded">
             <div class="card-body">
                <div class="row">
                    <div class="col-sm-12">  
  
                      <section class="text-gray-400">
                        <h2 class="mb-4 card-header"><i class="bi bi-link-45deg"> <?php echo e(__('messages.Links')); ?></i></h2>
                        <div class="card-body p-0 p-md-3">
                
                        <div class="table-responsive">
                        <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col"><?php echo e(__('messages.Link')); ?></th>
                            <th scope="col"><?php echo e(__('messages.Title')); ?></th>
                            <th scope="col"><?php echo e(__('messages.Clicks')); ?></th>
                            <th scope="col"><?php echo e(__('messages.Delete')); ?></th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td title="<?php echo e($link->link); ?>"><a style="color:#3985ff;text-decoration:underline;" href="<?php echo e($link->link); ?>" target="_blank"><?php echo e(Str::limit($link->link, 50)); ?></a></td>
                            <td title="<?php echo e($link->title); ?>"><?php echo e(Str::limit($link->title, 30)); ?></td>
                            <td class="text-right"><?php echo e($link->click_number); ?></td>
                            <td><a href="<?php echo e(route('deleteLinkUser', $link->id )); ?>" class="text-danger"><?php echo e(__('messages.Delete')); ?></a></td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                </div>
                
                            <ul class="pagination justify-content-center">
                                  <?php echo $links ?? ''->links(); ?>

                            </ul>
                
                <a class="btn btn-primary" href="<?php echo e(url('/admin/users/all')); ?>"><i class="bi bi-arrow-left-short"></i> <?php echo e(__('messages.Back')); ?></a>
                
                          </div>
                </section>
  
                    </div>
                </div>
             </div>
          </div>
       </div>


    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /htdocs/resources/views/panel/links.blade.php ENDPATH**/ ?>