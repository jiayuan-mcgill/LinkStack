


<?php $__env->startSection('content'); ?>
<div class="conatiner-fluid content-inner mt-n5 py-0">
    <div class="row">   
        
     <div class="col-lg-12">
        <div class="card   rounded">
            <div class="card-body">
               <div class="row">
                   <div class="col-sm-12">  

                    <h3 class="mb-4"><i class="bi bi-menu-up"></i> <?php echo e(__('messages.Dashboard')); ?></h3>
                    
                            <section class="mb-3 text-center p-4 w-full">
                                <div class=" d-flex">
                    
                                    <div class='p-2 h6'><i class="bi bi-link"></i> <?php echo e(__('messages.Total Links:')); ?> <span class='text-primary'><?php echo e($links); ?> </span></div>
                    
                                    <div class='p-2 h6'><i class="bi bi-eye"></i> <?php echo e(__('messages.Link Clicks:')); ?> <span class='text-primary'><?php echo e($clicks); ?></span></div>
                                </div>
                                <div class='text-center w-100'>
                                    <a href="<?php echo e(url('/studio/links')); ?>"><?php echo e(__('messages.View/Edit Links')); ?></a>
                    
                                </div>
                                <div class='w-100 text-left'>
                                    <h6><i class="bi bi-sort-up"></i> <?php echo e(__('messages.Top Links:')); ?></h6>
                    
                                                    <?php $i = 0; ?>
                    

                                                    <div class="bd-example" >
                                                        <ol class="list-group list-group-numbered" style="text-align: left;">
                                                          <?php if($toplinks == "[]"): ?>
                                                          <div class="container">
                                                            <div class="row justify-content-center mt-3">
                                                              <div class="col-6 text-center">
                                                                <p class="p-2"><?php echo e(__('messages.You haven’t added any links yet')); ?></p>
                                                              </div>
                                                            </div>
                                                          </div>                                                        
                                                          <?php else: ?>
                                                          <?php $__currentLoopData = $toplinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $linkName = str_replace('default ','',$link->name) ?>
                                                            <?php  $i++; ?>
                                                      
                                                            <?php if($link->name !== "phone" && $link->name !== 'heading' && $link->button_id !== 96): ?>
                                                              <li class="list-group-item d-flex justify-content-between align-items-start">
                                                                <div class="ms-2 me-auto text-truncate">
                                                                  <div class="fw-bold text-truncate"><?php echo e($link->title); ?></div>
                                                                  <?php echo e($link->link); ?>

                                                                </div>
                                                                <span class="badge bg-primary rounded-pill p-2"><?php echo e($link->click_number); ?> - <?php echo e(__('messages.clicks')); ?></span>
                                                              </li>
                                                            <?php endif; ?>
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                          <?php endif; ?>
                                                        </ol>
                                                      </div>

                            </section>

                   </div>
               </div>
            </div>
         </div>
        </div>

       <div class="col-lg-12">
          <div class="card   rounded">
             <div class="card-body">
                <div class="row">
                    <div class="col-sm-12">  

<?php if(auth()->user()->role == 'admin' && !config('linkstack.single_user_mode')): ?>
        <!-- Section: Design Block -->
        <section class="mb-3 text-gray-800 text-center p-4 w-full">
            <div class='font-weight-bold text-left h3'><?php echo e(__('messages.Site statistics:')); ?></div><br>
            <div class="d-flex flex-wrap justify-content-around">

                <div class="p-2">
                    <h3 class="text-primary"><strong><i class="bi bi-share-fill"> <?php echo e($siteLinks); ?> </i></strong></h3>
                    <span class="text-muted"><?php echo e(__('messages.Total links')); ?></span>
                </div>

                <div class="p-2">
                    <h3 class="text-primary"><strong><i class="bi bi-eye-fill"> <?php echo e($siteClicks); ?> </i></strong></h3>
                    <span class="text-muted"><?php echo e(__('messages.Total clicks')); ?></span>
                </div>

                <div class="p-2">
                    <h3 class="text-primary"><strong><i class="bi bi bi-person-fill"> <?php echo e($userNumber); ?></i></strong></h3>
                    <span class="text-muted"><?php echo e(__('messages.Total users')); ?></span>
                </div>

            </div>
        </section>

                    </div>
                </div>
             </div>
          </div>
       </div>       
       
       <div class="col-lg-12">
        <div class="card   rounded">
           <div class="card-body">
              <div class="row">
                  <div class="col-sm-12">  

      <!-- Section: Design Block -->
      <section class="mb-3 text-gray-800 text-center p-4 w-full">
          <div class='font-weight-bold text-left h3'><?php echo e(__('messages.Registrations:')); ?></div><br>
          <div class="d-flex flex-wrap justify-content-around">

              <div class="p-2">
                  <h3 class="text-primary"><strong> <?php echo e($lastMonthCount); ?> </i></strong></h3>
                  <span class="text-muted"><?php echo e(__('messages.Last 30 days')); ?></span>
              </div>

              <div class="p-2">
                  <h3 class="text-primary"><strong> <?php echo e($lastWeekCount); ?> </i></strong></h3>
                  <span class="text-muted"><?php echo e(__('messages.Last 7 days')); ?></span>
              </div>

              <div class="p-2">
                  <h3 class="text-primary"><strong> <?php echo e($last24HrsCount); ?></i></strong></h3>
                  <span class="text-muted"><?php echo e(__('messages.Last 24 hours')); ?></span>
              </div>

          </div>
      </section>

                  </div>
              </div>
           </div>
        </div>
     </div>   

     <div class="col-lg-12">
        <div class="card   rounded">
           <div class="card-body">
              <div class="row">
                  <div class="col-sm-12">  


      <!-- Section: Design Block -->
      <section class="mb-3 text-gray-800 text-center p-4 w-full">
          <div class='font-weight-bold text-left h3'><?php echo e(__('messages.Active users:')); ?></div><br>
          <div class="d-flex flex-wrap justify-content-around">

              <div class="p-2">
                  <h3 class="text-primary"><strong> <?php echo e($updatedLast30DaysCount); ?> </i></strong></h3>
                  <span class="text-muted"><?php echo e(__('messages.Last 30 days')); ?></span>
              </div>

              <div class="p-2">
                  <h3 class="text-primary"><strong> <?php echo e($updatedLast7DaysCount); ?> </i></strong></h3>
                  <span class="text-muted"><?php echo e(__('messages.Last 7 days')); ?></span>
              </div>

              <div class="p-2">
                  <h3 class="text-primary"><strong> <?php echo e($updatedLast24HrsCount); ?></i></strong></h3>
                  <span class="text-muted"><?php echo e(__('messages.Last 24 hours')); ?></span>
              </div>

          </div>
      </section>
                  </div>
              </div>
           </div>
        </div>
     </div>   
     <?php endif; ?>

    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /htdocs/resources/views/panel/index.blade.php ENDPATH**/ ?>