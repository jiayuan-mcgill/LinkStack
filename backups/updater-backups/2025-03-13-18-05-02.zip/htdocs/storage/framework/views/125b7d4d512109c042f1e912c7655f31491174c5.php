<?php if(env('FORCE_HTTPS') == 'true'): ?><?php URL::forceScheme('https'); header("Content-Security-Policy: upgrade-insecure-requests"); ?><?php endif; ?>
<html lang="<?php echo e(config('app.locale')); ?>">


<?php if(env('FORCE_ROUTE_HTTPS') == 'true'): ?>
<?php
if (! isset($_SERVER['HTTPS']) or $_SERVER['HTTPS'] == 'off' ) {
    $redirect_url = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("Location: $redirect_url");
    exit();
}
?>
<?php endif; ?>
<?php /**PATH /htdocs/resources/views/layouts/lang.blade.php ENDPATH**/ ?>