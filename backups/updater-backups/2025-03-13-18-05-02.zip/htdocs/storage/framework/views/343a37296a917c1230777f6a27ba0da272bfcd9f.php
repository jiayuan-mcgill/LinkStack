<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="mb-4 text-sm text-gray-600">
            <h2><?php echo e(__('messages.A new user has registered on')); ?> <?php echo e(str_replace(['http://', 'https://'], '', url(''))); ?> <?php echo e(__('messages.and is awaiting verification')); ?></h2>
            <p><?php echo e(__('messages.The user')); ?> <i><?php echo e($user); ?></i> <?php echo e(__('messages.with the email')); ?> <i><?php echo e($email); ?></i> <?php echo e(__('messages.has registered a new account on')); ?> <?php echo e(url('')); ?> <?php echo e(__('messages.and is awaiting confirmation by an admin')); ?> <?php echo e(__('messages.Click')); ?> <a href="<?php echo e(url('admin/users/all')); ?>"><?php echo e(__('messages.here')); ?></a> <?php echo e(__('messages.to verify the user')); ?></p>
        </div>
        <a href="<?php echo e(url('admin/users/all')); ?>"><button><?php echo e(__('messages.Manage users')); ?></button></a>
        <br><br>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH /htdocs/resources/views/auth/user-confirmation.blade.php ENDPATH**/ ?>