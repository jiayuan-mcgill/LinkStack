<label for='title' class='form-label'><?php echo e(__('messages.Spacing height')); ?></label>


<input type="range" class="custom-range" id="height" name='height' value=<?php echo e($params->height??5); ?> oninput="this.nextElementSibling.value = this.value"><output class='font-weight-bold'><?php echo e($params->height??5); ?></output>




<?php /**PATH /htdocs/resources/views/components/pageitems/spacer-form.blade.php ENDPATH**/ ?>