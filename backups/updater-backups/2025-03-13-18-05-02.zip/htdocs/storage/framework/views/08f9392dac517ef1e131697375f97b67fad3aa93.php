

<?php $__env->startSection('content'); ?>

<script src="<?php echo e(asset('resources/ckeditor/ckeditor.js')); ?>"></script>

<div class="conatiner-fluid content-inner mt-n5 py-0">
  <div class="row">   

    <form action="<?php echo e(route('editSitePage')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="col-lg-12">
          <div class="card   rounded">
             <div class="card-body">
                <div class="row">
                    <div class="col-sm-12">  
  
                          <div class="form-group col-lg-8">
                            <h3><?php echo e(footer('Terms')); ?></h3><br>
                            <textarea class="form-control ckeditor" name="terms" rows="3"><?php echo e($page->terms); ?></textarea>
                          </div>
                          
                          <button type="submit" class="mt-3 ml-3 btn btn-primary"><?php echo e(__('messages.Save')); ?></button>
  
                    </div>
                </div>
             </div>
          </div>
       </div>

        <div class="col-lg-12">
            <div class="card   rounded">
               <div class="card-body">
                  <div class="row">
                      <div class="col-sm-12">  
    
                            <div class="form-group col-lg-8">
                              <h3><?php echo e(footer('Privacy')); ?></h3><br>
                              <textarea class="form-control ckeditor" name="privacy" rows="3"><?php echo e($page->privacy); ?></textarea>
                            </div>

                            <button type="submit" class="mt-3 ml-3 btn btn-primary"><?php echo e(__('messages.Save')); ?></button>
    
                      </div>
                  </div>
               </div>
            </div>
         </div>

          <div class="col-lg-12">
              <div class="card   rounded">
                 <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">  
      
                              <div class="form-group col-lg-8">
                                <h3><?php echo e(footer('Contact')); ?></h3><br>
                                <textarea class="form-control ckeditor" name="contact" rows="3"><?php echo e($page->contact); ?></textarea>
                              </div>
                              
                              <button type="submit" class="mt-3 ml-3 btn btn-primary"><?php echo e(__('messages.Save')); ?></button>
      
                        </div>
                    </div>
                 </div>
              </div>
           </div>
  
          </form>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /htdocs/resources/views/panel/pages.blade.php ENDPATH**/ ?>